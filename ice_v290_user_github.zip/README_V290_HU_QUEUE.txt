ICE Inject v2.9.0 USER

Fitur baru:
- Halaman /Pack/Index mendeteksi CARTON/HU setelah scan.
- Otomatis mencari dan menekan nominal QTY.
- Membaca seluruh kolom QR CODE pada popup Content of Barcode.
- Setiap kode diubah menjadi MAT-<QR CODE>.
- Kode dimasukkan otomatis ke Antrean QR dan duplikat dilewati.
- Tombol cadangan "Ambil QR HU" tersedia bila pemuatan web lokal lambat.

Catatan: harus login dan tersambung Wi-Fi lokal perusahaan.
