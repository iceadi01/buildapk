ICE Inject v2.8.1 USER LOGIN + DUAL NETWORK

Tujuan:
- Tetap memakai aplikasi ICE Inject yang sama; tidak membuat aplikasi LP4M terpisah.
- LP4M (https://lp4m-lpw.liebrapermana.com) dan jaringan lokal 172.30.16.0/20 diarahkan melalui Wi-Fi perusahaan.
- Login akun, pemeriksaan sesi/lisensi, dan halaman internet umum diarahkan melalui data seluler.
- Permintaan jaringan seluler dipertahankan selama APK aktif agar notifikasi aplikasi lain tetap dapat memakai data.

Tampilan:
- Badge WIFI+DATA: kedua jaringan tersedia.
- Badge WIFI: hanya Wi-Fi yang terdeteksi.
- Badge DATA: hanya data seluler yang terdeteksi.
- Badge PUTUS: tidak ada jaringan yang terdeteksi.
- Ketuk badge jaringan untuk melihat jalur yang sedang dipakai.

Pemakaian:
1. Nyalakan data seluler dan Wi-Fi.
2. Sambungkan Wi-Fi perusahaan dan pilih tetap terhubung meskipun tanpa internet.
3. Buka ICE Inject dan login. Login memakai data seluler.
4. Setelah login, halaman LP4M otomatis memakai Wi-Fi perusahaan.

Catatan:
- APK biasa tidak dapat menyalakan tombol data/Wi-Fi secara paksa; keduanya harus dinyalakan pengguna.
- Fitur browser, kamera website, input scanner, Tampermonkey bridge, dan antrean QR v2.8.0 tetap dipertahankan.
- Package: com.mimar.iceinject
- Version code: 21
- Version name: 2.8.1
- Ditandatangani dengan signing key pembaruan ICE Inject yang sama.
