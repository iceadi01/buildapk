(function () {
  'use strict';

  var w = window;
  var VERSION = 5;
  var existing = w.__LPWScannerBridge;
  if (existing && existing.version === VERSION) {
    try { existing.patch(); } catch (_) {}
    return;
  }

  var callbacks = [];
  var patched = {};
  var patchTimers = [];
  var observer = null;
  var lastPatchAt = 0;
  var lastGuideAt = 0;
  var lastCount = -1;
  var recent = {};
  var queue = [];
  var processing = false;
  var destroyed = false;

  var MAX_CALLBACKS = 4;
  var MAX_QUEUE = 24;
  var CALLBACK_TTL = 3 * 60 * 1000;
  var DUPLICATE_MS = 1100;
  var SEND_GAP_MS = 140;

  function now() { return Date.now ? Date.now() : new Date().getTime(); }

  function androidCall(name, args) {
    try {
      if (w.AndroidBridge && typeof w.AndroidBridge[name] === 'function') {
        w.AndroidBridge[name].apply(w.AndroidBridge, args || []);
      }
    } catch (_) {}
  }

  function report(message) {
    androidCall('onStatus', [String(message || '')]);
  }

  function reportCount(force) {
    var count = callbacks.length;
    if (!force && count === lastCount) return;
    lastCount = count;
    androidCall('onCallbackCount', [count]);
  }

  function callbackSources() {
    var out = [];
    for (var i = callbacks.length - 1; i >= 0; i--) {
      var source = callbacks[i] && callbacks[i].source;
      if (source && out.indexOf(source) < 0) out.push(source);
    }
    return out;
  }

  function cleanupRecent() {
    var cutoff = now() - Math.max(DUPLICATE_MS * 4, 10000);
    for (var key in recent) {
      if (Object.prototype.hasOwnProperty.call(recent, key) && recent[key] < cutoff) {
        delete recent[key];
      }
    }
  }

  function cleanupCallbacks() {
    var cutoff = now() - CALLBACK_TTL;
    var next = [];
    for (var i = 0; i < callbacks.length; i++) {
      var entry = callbacks[i];
      if (!entry || typeof entry.fn !== 'function') continue;
      if (entry.addedAt && entry.addedAt < cutoff) continue;
      next.push(entry);
    }
    callbacks = next.slice(-MAX_CALLBACKS);
    reportCount(false);
  }

  function addCallback(fn, source, mode) {
    if (typeof fn !== 'function') return;
    source = source || 'callback';
    mode = mode || 'html5';

    var stamp = now();
    var next = [];
    for (var i = 0; i < callbacks.length; i++) {
      var item = callbacks[i];
      if (!item || item.fn === fn || item.source === source) continue;
      next.push(item);
    }
    next.push({ fn: fn, source: source, mode: mode, addedAt: stamp });
    callbacks = next.slice(-MAX_CALLBACKS);
    reportCount(false);
    report('Scanner siap. Jalur aktif: ' + source + '.');
  }

  function decodedResult(text) {
    return {
      decodedText: text,
      text: text,
      rawValue: text,
      data: text,
      code: text,
      barcode: text,
      result: {
        text: text,
        format: { formatName: 'QR_CODE', format: 'QR_CODE' }
      }
    };
  }

  function wrapMethod(proto, name, makeWrapper, key) {
    try {
      if (!proto || typeof proto[name] !== 'function') return false;
      if (proto[name].__iceBridgeV4) return true;
      var original = proto[name];
      var wrapped = makeWrapper(original);
      wrapped.__iceBridgeV4 = true;
      wrapped.__iceOriginal = original;
      proto[name] = wrapped;
      patched[key || name] = true;
      return true;
    } catch (_) {
      return false;
    }
  }

  function patchHtml5Qrcode() {
    try {
      var Html5Qrcode = w.Html5Qrcode;
      if (typeof Html5Qrcode === 'function' && Html5Qrcode.prototype) {
        wrapMethod(Html5Qrcode.prototype, 'start', function (original) {
          return function (cameraIdOrConfig, configuration, successCallback, errorCallback) {
            addCallback(successCallback, 'Html5Qrcode.start', 'html5');
            return original.call(this, cameraIdOrConfig, configuration, successCallback, errorCallback);
          };
        }, 'Html5Qrcode.start');
      }
    } catch (_) {}

    try {
      var Scanner = w.Html5QrcodeScanner;
      if (typeof Scanner === 'function' && Scanner.prototype) {
        wrapMethod(Scanner.prototype, 'render', function (original) {
          return function (successCallback, errorCallback) {
            addCallback(successCallback, 'Html5QrcodeScanner.render', 'html5');
            return original.call(this, successCallback, errorCallback);
          };
        }, 'Html5QrcodeScanner.render');
      }
    } catch (_) {}
  }

  function patchOtherLibraries() {
    try {
      var QrScanner = w.QrScanner;
      if (typeof QrScanner === 'function' && !QrScanner.__iceBridgeV4Wrapped && typeof Proxy === 'function') {
        var Wrapped = new Proxy(QrScanner, {
          construct: function (target, args, newTarget) {
            addCallback(args && args[1], 'QrScanner.constructor', 'qrscanner');
            return Reflect.construct(target, args, newTarget === Wrapped ? target : newTarget);
          }
        });
        Wrapped.__iceBridgeV4Wrapped = true;
        w.QrScanner = Wrapped;
      }
    } catch (_) {}

    try {
      var InstascanScanner = w.Instascan && w.Instascan.Scanner;
      if (typeof InstascanScanner === 'function' && InstascanScanner.prototype) {
        wrapMethod(InstascanScanner.prototype, 'addListener', function (original) {
          return function (eventName, callback) {
            if (String(eventName).toLowerCase() === 'scan') {
              addCallback(callback, 'Instascan.addListener', 'text');
            }
            return original.call(this, eventName, callback);
          };
        }, 'Instascan.addListener');
      }
    } catch (_) {}

    try {
      var Quagga = w.Quagga;
      if (Quagga && typeof Quagga.onDetected === 'function' && !Quagga.onDetected.__iceBridgeV4) {
        var originalOnDetected = Quagga.onDetected;
        var wrappedOnDetected = function (callback) {
          addCallback(callback, 'Quagga.onDetected', 'quagga');
          return originalOnDetected.call(this, callback);
        };
        wrappedOnDetected.__iceBridgeV4 = true;
        Quagga.onDetected = wrappedOnDetected;
      }
    } catch (_) {}
  }

  function tryContinuousFocus(video) {
    try {
      if (!video || !video.srcObject || !video.srcObject.getVideoTracks) return;
      var track = video.srcObject.getVideoTracks()[0];
      if (!track || track.__iceFocusV4) return;
      track.__iceFocusV4 = true;
      if (!track.getCapabilities || !track.applyConstraints) return;
      var caps = track.getCapabilities() || {};
      if (caps.focusMode && Array.prototype.indexOf.call(caps.focusMode, 'continuous') >= 0) {
        track.applyConstraints({ advanced: [{ focusMode: 'continuous' }] }).catch(function () {});
      }
    } catch (_) {}
  }

  function directGuide(parent) {
    try {
      var children = parent.children || [];
      for (var i = 0; i < children.length; i++) {
        if (children[i] && children[i].classList && children[i].classList.contains('ice-scan-guide')) {
          return children[i];
        }
      }
    } catch (_) {}
    return null;
  }

  function ensureScannerGuide() {
    if (document.hidden) return;
    var videos = [];
    try { videos = Array.prototype.slice.call(document.querySelectorAll('video')); } catch (_) {}
    for (var i = 0; i < videos.length; i++) {
      var video = videos[i];
      try {
        var rect = video.getBoundingClientRect();
        var style = w.getComputedStyle(video);
        if (rect.width < 160 || rect.height < 120 || style.display === 'none' || style.visibility === 'hidden') continue;
        tryContinuousFocus(video);
        var parent = video.parentElement;
        if (!parent || directGuide(parent)) continue;
        if (w.getComputedStyle(parent).position === 'static') parent.style.position = 'relative';

        var guide = document.createElement('div');
        guide.className = 'ice-scan-guide';
        guide.setAttribute('aria-hidden', 'true');
        guide.innerHTML = '<span>Pas-kan QR / barcode di dalam kotak</span><b></b>';
        guide.style.cssText = 'position:absolute;left:8%;right:8%;top:23%;height:48%;z-index:2147483000;pointer-events:none;border:2px solid rgba(34,197,94,.9);border-radius:14px;box-sizing:border-box;';
        var label = guide.querySelector('span');
        if (label) label.style.cssText = 'position:absolute;left:50%;bottom:-34px;transform:translateX(-50%);white-space:nowrap;background:rgba(15,23,42,.82);color:#fff;border-radius:999px;padding:6px 10px;font:600 12px system-ui,sans-serif;';
        var line = guide.querySelector('b');
        if (line) line.style.cssText = 'position:absolute;left:7%;right:7%;top:50%;height:2px;background:#22c55e;box-shadow:0 0 8px #22c55e;';
        parent.appendChild(guide);
      } catch (_) {}
    }
  }

  function patch() {
    if (destroyed) return;
    var stamp = now();
    if (stamp - lastPatchAt < 220) return;
    lastPatchAt = stamp;
    cleanupCallbacks();
    cleanupRecent();
    patchHtml5Qrcode();
    patchOtherLibraries();
    if (stamp - lastGuideAt > 1200) {
      lastGuideAt = stamp;
      ensureScannerGuide();
    }
    reportCount(false);
  }

  function clearPatchTimers() {
    for (var i = 0; i < patchTimers.length; i++) {
      try { w.clearTimeout(patchTimers[i]); } catch (_) {}
    }
    patchTimers = [];
  }

  function schedulePatch() {
    clearPatchTimers();
    var delays = [0, 250, 700, 1500, 3000, 6000, 12000, 22000];
    for (var i = 0; i < delays.length; i++) {
      (function (delay) {
        patchTimers.push(w.setTimeout(function () {
          patch();
        }, delay));
      })(delays[i]);
    }
  }

  function installObserver() {
    if (observer || !w.MutationObserver || !document.documentElement) return;
    var timer = 0;
    observer = new w.MutationObserver(function (records) {
      if (destroyed || document.hidden) return;
      var useful = false;
      for (var i = 0; i < records.length && !useful; i++) {
        var added = records[i].addedNodes || [];
        for (var j = 0; j < added.length; j++) {
          var node = added[j];
          if (!node || node.nodeType !== 1) continue;
          var tag = String(node.tagName || '').toLowerCase();
          if (tag === 'video' || tag === 'script' || (node.querySelector && node.querySelector('video,script'))) {
            useful = true;
            break;
          }
        }
      }
      if (!useful || timer) return;
      timer = w.setTimeout(function () {
        timer = 0;
        patch();
      }, 350);
    });
    try { observer.observe(document.documentElement, { childList: true, subtree: true }); } catch (_) {}
  }

  function invokeCallback(entry, text) {
    var detail = decodedResult(text);
    if (entry.mode === 'qrscanner') {
      return entry.fn({
        data: text,
        text: text,
        rawValue: text,
        cornerPoints: [],
        toString: function () { return text; },
        valueOf: function () { return text; }
      });
    }
    if (entry.mode === 'quagga') {
      return entry.fn({
        codeResult: { code: text, format: 'code_128' },
        result: { code: text }
      });
    }
    return entry.fn(text, detail);
  }

  function invokeLatestCaptured(text) {
    cleanupCallbacks();
    var attempted = 0;
    for (var i = callbacks.length - 1; i >= 0 && attempted < 2; i--) {
      var entry = callbacks[i];
      if (!entry || typeof entry.fn !== 'function') continue;
      attempted++;
      try {
        invokeCallback(entry, text);
        entry.addedAt = now();
        return { called: 1, source: entry.source, errors: 0 };
      } catch (_) {}
    }
    return { called: 0, source: '', errors: attempted };
  }

  function invokeOneNamed(text) {
    var detail = decodedResult(text);
    var names = [
      'onScanSuccess', 'qrCodeSuccessCallback', 'scanSuccess',
      'scannerSuccess', 'onQrCodeScanned', 'onBarcodeScanned',
      'handleScan', 'handleBarcode', 'processBarcode'
    ];
    for (var i = 0; i < names.length; i++) {
      try {
        if (typeof w[names[i]] === 'function') {
          w[names[i]](text, detail);
          return names[i];
        }
      } catch (_) {}
    }
    return '';
  }

  function fieldScore(el) {
    var meta = '';
    try {
      meta = [
        el.id, el.name, el.type, el.placeholder,
        el.getAttribute && el.getAttribute('aria-label'),
        el.getAttribute && el.getAttribute('data-testid'),
        typeof el.className === 'string' ? el.className : ''
      ].filter(Boolean).join(' ').toLowerCase();
    } catch (_) {}
    var score = 0;
    if (/barcode/.test(meta)) score += 70;
    if (/(^|\W)hu($|\W)/.test(meta)) score += 65;
    if (/qr|scan|scanner/.test(meta)) score += 45;
    if (/kode|code/.test(meta)) score += 30;
    if (/serial|nomor|number/.test(meta)) score += 12;
    try {
      if (el.disabled || el.readOnly || el.type === 'hidden') score -= 60;
      var rect = el.getBoundingClientRect();
      if (rect.width > 20 && rect.height > 12) score += 10;
    } catch (_) {}
    return score;
  }

  function setNativeValue(el, text) {
    var tag = String(el.tagName || '').toLowerCase();
    if (tag === 'input') {
      var inputSetter = Object.getOwnPropertyDescriptor(w.HTMLInputElement.prototype, 'value');
      if (inputSetter && inputSetter.set) inputSetter.set.call(el, text); else el.value = text;
    } else if (tag === 'textarea') {
      var areaSetter = Object.getOwnPropertyDescriptor(w.HTMLTextAreaElement.prototype, 'value');
      if (areaSetter && areaSetter.set) areaSetter.set.call(el, text); else el.value = text;
    } else if (el.isContentEditable) {
      el.textContent = text;
    }
  }

  function fillBestInput(text) {
    var nodes = [];
    try { nodes = Array.prototype.slice.call(document.querySelectorAll('input,textarea,[contenteditable="true"]')); } catch (_) {}
    var best = null;
    var bestScore = 19;
    var limit = Math.min(nodes.length, 250);
    for (var i = 0; i < limit; i++) {
      var score = fieldScore(nodes[i]);
      if (score > bestScore) {
        best = nodes[i];
        bestScore = score;
      }
    }
    if (!best) return false;
    try {
      best.disabled = false;
      best.readOnly = false;
      best.removeAttribute('disabled');
      best.removeAttribute('readonly');
      setNativeValue(best, text);
      try { best.focus(); } catch (_) {}
      try { best.dispatchEvent(new Event('input', { bubbles: true })); } catch (_) {}
      try { best.dispatchEvent(new Event('change', { bubbles: true })); } catch (_) {}
      return true;
    } catch (_) {
      return false;
    }
  }

  function dispatchFallbackEvents(text) {
    var detail = decodedResult(text);
    var names = ['scanSuccess', 'qr-scanned', 'barcode-scanned'];
    var count = 0;
    for (var i = 0; i < names.length; i++) {
      try {
        document.dispatchEvent(new CustomEvent(names[i], { bubbles: true, detail: detail }));
        count++;
      } catch (_) {}
    }
    return count;
  }

  function processOne(item) {
    patch();
    var captured = invokeLatestCaptured(item.text);
    var named = '';
    var input = false;
    var events = 0;

    if (!captured.called) named = invokeOneNamed(item.text);
    if (!captured.called && !named) input = fillBestInput(item.text);
    if (!captured.called && !named && !input) events = dispatchFallbackEvents(item.text);

    var ok = !!(captured.called || named || input);
    var result = {
      ok: ok,
      callbacks: captured.called,
      source: captured.source,
      named: named,
      inputs: input ? 1 : 0,
      events: events,
      errors: captured.errors,
      captured: callbacks.length,
      queued: queue.length,
      sources: callbackSources(),
      requestId: item.requestId || '',
      text: item.text,
      reason: ok ? '' : 'scanner_not_ready'
    };

    if (captured.called) report('Kode terkirim ke scanner aktif.');
    else if (named) report('Kode terkirim lewat ' + named + '.');
    else if (input) report('Kode diisi ke kolom barcode/HU.');
    else report('Scanner belum siap. Buka ulang menu Scan QR.');

    androidCall('onSendReport', [JSON.stringify(result)]);
  }

  function processQueue() {
    if (processing || destroyed) return;
    processing = true;

    function next() {
      if (destroyed || !queue.length) {
        processing = false;
        return;
      }
      var item = queue.shift();
      try { processOne(item); } catch (_) {}
      w.setTimeout(next, SEND_GAP_MS);
    }

    next();
  }

  function send(text, requestId) {
    text = String(text == null ? '' : text).trim();
    if (!text) {
      report('Kode masih kosong.');
      return JSON.stringify({ ok: false, reason: 'empty' });
    }

    var stamp = now();
    if (recent[text] && stamp - recent[text] < DUPLICATE_MS) {
      report('Kode sama baru saja diproses.');
      return JSON.stringify({ ok: false, reason: 'duplicate' });
    }
    recent[text] = stamp;
    cleanupRecent();

    if (queue.length >= MAX_QUEUE) {
      report('Antrean scan penuh. Tunggu sebentar.');
      return JSON.stringify({ ok: false, reason: 'queue_full', queued: queue.length });
    }

    queue.push({ text: text, addedAt: stamp, requestId: String(requestId == null ? '' : requestId) });
    processQueue();
    return JSON.stringify({ ok: true, queued: queue.length, processing: processing });
  }

  function status() {
    patch();
    return JSON.stringify({
      version: VERSION,
      callbacks: callbacks.length,
      sources: callbackSources(),
      queued: queue.length,
      processing: processing,
      html5Qrcode: typeof w.Html5Qrcode === 'function',
      html5Scanner: typeof w.Html5QrcodeScanner === 'function'
    });
  }



  // LP4M Pack: scan HU -> klik QTY -> ambil seluruh QR CODE -> antrean MAT-...
  var huAuto = { lastCarton: '', busy: false, timer: 0, button: null };

  function normText(v) { return String(v == null ? '' : v).replace(/\s+/g, ' ').trim(); }
  function visible(el) {
    try { var r=el.getBoundingClientRect(), st=w.getComputedStyle(el); return r.width>1 && r.height>1 && st.display!=='none' && st.visibility!=='hidden'; } catch (_) { return false; }
  }
  function isPackPage() { return /\/Pack\/Index/i.test(String(location.pathname || '')); }
  function findCartonInput() {
    var all=[]; try { all=[].slice.call(document.querySelectorAll('input')); } catch (_) {}
    var best=null, score=-1;
    all.forEach(function(el){
      var meta=normText([el.id,el.name,el.placeholder,el.getAttribute('aria-label')].join(' ')).toLowerCase();
      var parent=el.parentElement; for(var i=0;i<3&&parent;i++,parent=parent.parentElement) meta+=' '+normText(parent.innerText).toLowerCase();
      var sc=(/carton/.test(meta)?100:0)+(/barcode|scan/.test(meta)?20:0)+(visible(el)?10:0);
      if(sc>score){score=sc;best=el;}
    });
    return score>=80?best:null;
  }
  function findQtyClickable() {
    var tables=[]; try { tables=[].slice.call(document.querySelectorAll('table')); } catch (_) {}
    for(var t=0;t<tables.length;t++){
      var th=[].slice.call(tables[t].querySelectorAll('thead th'));
      var qi=-1; for(var i=0;i<th.length;i++) if(/^qty|quantity$/i.test(normText(th[i].innerText))){qi=i;break;}
      if(qi>=0){
        var rows=[].slice.call(tables[t].querySelectorAll('tbody tr'));
        for(var r=0;r<rows.length;r++){
          var cells=rows[r].children; if(cells[qi] && normText(cells[qi].innerText) && visible(cells[qi])) return cells[qi].querySelector('a,button,[role=button]')||cells[qi];
        }
      }
    }
    var nodes=[]; try { nodes=[].slice.call(document.querySelectorAll('a,button,[role=button],td,span,div')); } catch (_) {}
    var best=null, bestScore=-1;
    nodes.slice(0,1500).forEach(function(el){
      if(!visible(el)) return; var txt=normText(el.innerText); if(!/^\d+(?:[.,]\d+)?$/.test(txt)) return;
      var ctx='', p=el; for(var i=0;i<4&&p;i++,p=p.parentElement) ctx+=' '+normText(p.innerText).toLowerCase();
      var sc=(/\bqty\b|quantity/.test(ctx)?80:0)+((el.tagName==='A'||el.tagName==='BUTTON'||el.onclick||el.getAttribute('data-toggle'))?25:0);
      if(sc>bestScore){bestScore=sc;best=el;}
    });
    return bestScore>=80?best:null;
  }
  function findBarcodeModal() {
    var candidates=[]; try { candidates=[].slice.call(document.querySelectorAll('.modal,.swal2-container,[role=dialog]')); } catch (_) {}
    for(var i=candidates.length-1;i>=0;i--) if(visible(candidates[i]) && /content of barcode/i.test(normText(candidates[i].innerText))) return candidates[i];
    return null;
  }
  function qrColumnIndex(table) {
    var heads=[].slice.call(table.querySelectorAll('thead th'));
    for(var i=0;i<heads.length;i++) if(/qr\s*code/i.test(normText(heads[i].innerText))) return i;
    return -1;
  }
  function collectQrFromTable(table, out) {
    var qi=qrColumnIndex(table); if(qi<0) return;
    try {
      if(w.jQuery && w.jQuery.fn && w.jQuery.fn.DataTable && w.jQuery.fn.DataTable.isDataTable(table)){
        var api=w.jQuery(table).DataTable(); var arr=api.column(qi).data().toArray();
        arr.forEach(function(v){ var d=document.createElement('div'); d.innerHTML=String(v); var x=normText(d.textContent); if(x) out[x]=1; });
      }
    } catch (_) {}
    var rows=[].slice.call(table.querySelectorAll('tbody tr'));
    rows.forEach(function(row){ var c=row.children[qi]; if(c){var x=normText(c.innerText); if(x && !/no data/i.test(x)) out[x]=1;} });
  }
  function extractAllQr(modal, done) {
    var out={}, pages=0;
    function step(){
      pages++; var tables=[].slice.call(modal.querySelectorAll('table')); tables.forEach(function(t){collectQrFromTable(t,out);});
      var next=null; var btns=[].slice.call(modal.querySelectorAll('a,button'));
      for(var i=0;i<btns.length;i++){var tx=normText(btns[i].innerText).toLowerCase(); if(tx==='next'||tx==='berikutnya'||tx==='›'||tx==='>'){next=btns[i];break;}}
      var disabled=!next || next.disabled || /disabled/.test(String(next.className)) || next.getAttribute('aria-disabled')==='true';
      if(!disabled && pages<120){ try{next.click();}catch(_){} w.setTimeout(step,180); }
      else done(Object.keys(out));
    }
    step();
  }
  function enqueueHuCodes(carton,codes){
    var clean=[], seen={};
    codes.forEach(function(x){x=normText(x); if(!x) return; var c=/^MAT-/i.test(x)?x:'MAT-'+x; if(!seen[c]){seen[c]=1;clean.push(c);}});
    if(!clean.length){report('HU ditemukan, tetapi QR CODE kosong.');return;}
    androidCall('enqueueHuQrCodes',[JSON.stringify({carton:carton,codes:clean})]);
    report(clean.length+' QR dari HU masuk antrean.');
  }
  function runHuAutomation(force){
    if(!isPackPage()||huAuto.busy) return;
    var inp=findCartonInput(), carton=inp?normText(inp.value):'';
    if(!carton){ if(force) report('Scan atau isi CARTON terlebih dahulu.'); return; }
    if(!force && carton===huAuto.lastCarton) return;
    huAuto.busy=true; report('Mencari QTY untuk HU '+carton+'…');
    var tries=0;
    function waitQty(){
      var modal=findBarcodeModal();
      if(modal) return readModal(modal);
      var q=findQtyClickable();
      if(q){try{q.scrollIntoView({block:'center'});}catch(_){} try{q.click();}catch(_){} return waitModal();}
      if(++tries<35) return w.setTimeout(waitQty,250);
      huAuto.busy=false; report('QTY belum ditemukan. Tekan tombol Ambil QR HU setelah data tampil.');
    }
    function waitModal(){var n=0;(function f(){var m=findBarcodeModal();if(m)return readModal(m);if(++n<30)return w.setTimeout(f,200);huAuto.busy=false;report('Popup Content of Barcode belum muncul.');})();}
    function readModal(m){extractAllQr(m,function(codes){huAuto.lastCarton=carton;huAuto.busy=false;enqueueHuCodes(carton,codes);});}
    waitQty();
  }
  function scheduleHuAuto(){ if(!isPackPage())return; try{w.clearTimeout(huAuto.timer);}catch(_){} huAuto.timer=w.setTimeout(function(){runHuAutomation(false);},700); }
  function installHuButton(){
    if(!isPackPage()||document.getElementById('ice-hu-grab')) return;
    var b=document.createElement('button'); b.id='ice-hu-grab'; b.type='button'; b.textContent='Ambil QR HU';
    b.style.cssText='position:fixed;left:14px;bottom:82px;z-index:2147483646;border:0;border-radius:999px;padding:11px 15px;background:#111827;color:#fff;font:700 13px system-ui;box-shadow:0 5px 18px rgba(0,0,0,.28)';
    b.onclick=function(){runHuAutomation(true);}; document.body.appendChild(b); huAuto.button=b;
  }
  function installHuAutomation(){
    if(!isPackPage()) return; installHuButton();
    document.addEventListener('input',function(e){if(e.target===findCartonInput())scheduleHuAuto();},true);
    document.addEventListener('change',function(e){if(e.target===findCartonInput())scheduleHuAuto();},true);
    document.addEventListener('keyup',function(e){if((e.key==='Enter'||e.keyCode===13)&&e.target===findCartonInput())scheduleHuAuto();},true);
    var mo=new MutationObserver(function(){installHuButton();scheduleHuAuto();});
    try{mo.observe(document.documentElement,{childList:true,subtree:true,characterData:true});}catch(_){}
    w.setTimeout(scheduleHuAuto,1200);
  }

  function destroy() {
    destroyed = true;
    clearPatchTimers();
    queue = [];
    callbacks = [];
    try { if (observer) observer.disconnect(); } catch (_) {}
    observer = null;
    reportCount(true);
  }

  w.__LPWScannerBridge = {
    version: VERSION,
    patch: patch,
    send: send,
    status: status,
    report: report,
    destroy: destroy,
    getCallbackCount: function () { return callbacks.length; }
  };

  try {
    document.addEventListener('visibilitychange', function () {
      if (!document.hidden) schedulePatch();
    }, false);
    w.addEventListener('pageshow', schedulePatch, false);
    w.addEventListener('pagehide', function () {
      clearPatchTimers();
      queue = [];
    }, false);
  } catch (_) {}

  patch();
  installObserver();
  installHuAutomation();
  schedulePatch();
  report('Tools stabil siap. Buka menu Scan QR lalu kirim kode.');
})();
