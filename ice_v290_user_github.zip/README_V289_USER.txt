ICE Inject User v2.8.9

Perubahan:
- Tombol "Foto QR lalu scan" sekarang memakai kamera internal yang sama dengan mode Jepret Banyak.
- Tidak lagi membuka aplikasi kamera bawaan Android.
- Setelah dijepret, hasil QR/barcode ditampilkan langsung di layar kamera.
- Jika berhasil, hasil ditampilkan sekitar 1,8 detik lalu otomatis kembali dan dikirim ke scanner.
- Jika gagal dibaca, kamera tetap terbuka dan pengguna dapat langsung menjepret ulang.
- Hasil yang terbaca juga ditampilkan pada kolom input dan status panel.
- Mode Jepret Banyak ke antrean dan Kirim 1 dari antrean tetap tersedia.

Build: jalankan build_user.sh melalui workflow GitHub Actions.
Output: ice_v289_user.apk
