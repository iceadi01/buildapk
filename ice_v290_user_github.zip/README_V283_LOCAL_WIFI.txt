ICE Inject v2.8.3 — Wi-Fi kerja lokal khusus

Perubahan utama:
- Menghapus klaim/layanan "dual seluruh HP" v2.8.2 yang hanya menahan radio seluler dan tidak dapat mengubah jalur aplikasi lain.
- Menambahkan koneksi Wi-Fi local-only melalui WifiNetworkSpecifier (Android 10+).
- ICE Inject dapat memakai Wi-Fi perusahaan, sementara jaringan utama HP tetap data seluler untuk WhatsApp, Chrome, Telegram, dan notifikasi.
- Indikator DUAL OK hanya muncul bila Wi-Fi khusus ICE aktif dan jaringan default HP benar-benar data seluler.

Cara pertama kali:
1. Nyalakan data seluler.
2. Dari Pengaturan Wi-Fi, lupakan/putuskan Wi-Fi perusahaan agar tidak menjadi jaringan default seluruh HP.
3. Buka ICE Inject, login memakai data seluler.
4. Tekan indikator jaringan, isi SSID/password Wi-Fi perusahaan, lalu tekan Hubungkan.
5. Setujui dialog koneksi Android. Setelah berhasil indikator menjadi DUAL OK.

Catatan:
- Password disimpan hanya di penyimpanan privat aplikasi (android:allowBackup=false).
- Jika Wi-Fi memakai WPA-Enterprise/EAP, versi ini belum mendukung kredensial enterprise.
- Hasil tetap perlu diuji pada firmware HiOS/Tecno karena dukungan OEM dapat berbeda.
