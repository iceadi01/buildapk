ICE Inject User v2.8.7

PERBAIKAN JEPRET BANYAK
- Mode Jepret Banyak sekarang memakai kamera di dalam aplikasi, jadi kamera tidak keluar-masuk setiap foto.
- Setelah menekan JEPRET, preview kamera langsung aktif kembali dan pengguna dapat menjepret QR berikutnya.
- Hasil QR langsung ditambahkan ke Antrean QR dan tidak dimasukkan ke kolom ketik.
- Jika QR gagal dibaca, notifikasi tampil di atas kamera; kamera tetap terbuka dan dapat langsung menjepret ulang.
- Foto diproses langsung dari memori, tidak masuk galeri dan tidak disimpan permanen.
- Duplikat dilewati otomatis.
- Tombol FLASH tersedia untuk kondisi gelap.
- Tekan SELESAI atau Kembali untuk menutup kamera. Jika masih ada foto yang sedang dibaca, aplikasi menunggu sampai proses selesai.
- Setelah kamera ditutup, antrean tidak terbuka secara paksa. Tekan tombol Antrean QR saat siap mengirim.

FITUR FOTO SATUAN
- Tombol Foto QR lalu scan tetap menggunakan kamera satuan dan langsung mengirim hasil.

VERSI
- Version code: 27
- Version name: 2.8.7
- Package: com.mimar.iceinject
- Mode user / ADMIN_BUILD=false.

BUILD
- Jalankan build_user.sh atau workflow .github/workflows/build-apk.yml.
- Hasil release: ice_v287_user.apk.
