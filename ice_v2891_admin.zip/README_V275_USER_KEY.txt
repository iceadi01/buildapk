ICE Inject v2.7.7 USER KEY BUILD

Perubahan penting:
- Ini USER build, bukan admin build. ADMIN_BUILD = false.
- Aktivasi tidak hanya lewat WebView. Dialog aktivasi sekarang punya kolom input key langsung.
- Tombol "Aktivasi Key" memanggil server /activate-app.php dan menyimpan expires_at/token/key ke SharedPreferences APK.
- Tombol "Buka Web" tetap tersedia sebagai cadangan.
- Cocok dengan server license v6.5+.

Cara build cepat:
1. Di repo GitHub, hapus ZIP lama agar workflow tidak salah build.
2. Upload ZIP source ini saja.
3. Jalankan workflow Build APK From ZIP.
4. Download artifact ice_v275_user_key_debug_apk.
5. Extract artifact ZIP, install APK di dalamnya.
6. Uninstall APK lama dulu sebelum install jika tanda tangan berbeda.

Cara aktivasi di APK:
1. Buka APK.
2. Isi URL server, contoh https://accuracy.fwh.is
3. Isi key lisensi.
4. Tekan Aktivasi Key.
