#!/usr/bin/env bash
set -euo pipefail

OUT_NAME="ice_v2891_admin.apk"
KEYSTORE="signing/ice_v271_release.keystore"
KEY_ALIAS="icev271"
STORE_PASS="${ICE_STORE_PASS:-ICEv271Stable!}"
KEY_PASS="${ICE_KEY_PASS:-$STORE_PASS}"

command -v gradle >/dev/null 2>&1 || { echo "Gradle belum terpasang." >&2; exit 1; }
gradle :app:assembleRelease

SDK_ROOT="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"
if [[ -z "$SDK_ROOT" || ! -d "$SDK_ROOT/build-tools" ]]; then
  echo "ANDROID_SDK_ROOT/ANDROID_HOME belum benar." >&2
  exit 1
fi

BUILD_TOOLS="$(find "$SDK_ROOT/build-tools" -mindepth 1 -maxdepth 1 -type d | sort -V | tail -n 1)"
ZIPALIGN="$BUILD_TOOLS/zipalign"
APKSIGNER="$BUILD_TOOLS/apksigner"
UNSIGNED="app/build/outputs/apk/release/app-release-unsigned.apk"
ALIGNED="app/build/outputs/apk/release/app-release-aligned.apk"

[[ -f "$UNSIGNED" ]] || { echo "APK unsigned tidak ditemukan: $UNSIGNED" >&2; exit 1; }
[[ -x "$ZIPALIGN" ]] || { echo "zipalign tidak ditemukan." >&2; exit 1; }
[[ -x "$APKSIGNER" ]] || { echo "apksigner tidak ditemukan." >&2; exit 1; }

"$ZIPALIGN" -f 4 "$UNSIGNED" "$ALIGNED"
"$APKSIGNER" sign \
  --ks "$KEYSTORE" \
  --ks-key-alias "$KEY_ALIAS" \
  --ks-pass "pass:$STORE_PASS" \
  --key-pass "pass:$KEY_PASS" \
  --out "$OUT_NAME" \
  "$ALIGNED"
"$APKSIGNER" verify --verbose --print-certs "$OUT_NAME"
echo "Selesai: $OUT_NAME"
